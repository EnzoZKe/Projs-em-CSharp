namespace Categorias;
public class Categoria
{
    private string CategoriaNome { get; set; }
    private int IDpedido { get; set; }

    public Categoria()
    {
        this.CategoriaNome = CategoriaNome;
        this.IDpedido = 0;
    }
}